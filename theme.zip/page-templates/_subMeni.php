<?php
/**
 * Created by PhpStorm.
 * User: st00ne1
 * Date: 19/07/15
 * Time: 16:49
 */
?>
<div class="col-3">
    <article>
        <a href="" class="gridblock two" data-scroll-to="on" data-scroll-to-target=".scroll-<?= $data['id']; ?>">
            <figure>
                <img src="<?= $data['ikona']; ?>" alt="Image"/>
            </figure>
            <h4><?= $data['naslov']; ?></h4>
        </a>
    </article>
</div>